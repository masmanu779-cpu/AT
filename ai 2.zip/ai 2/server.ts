import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import multer from "multer";
import dotenv from "dotenv";

dotenv.config();

const upload = multer({ storage: multer.memoryStorage() });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini Setup
  let ai: GoogleGenAI | null = null;
  const getAi = () => {
    if (!ai) {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error("GEMINI_API_KEY is not set.");
      }
      ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    }
    return ai;
  };

  // Chat API
  app.post("/api/chat", async (req, res) => {
    try {
      const { prompt, history } = req.body;
      const genAi = getAi();
      
      const systemInstruction = "You are AutoMind AI, an Automobile Engineering Assistant. Answer questions related to automobile engineering, mechanical engineering, workshop safety, and vehicle systems. Be educational, helpful, and concise.";
      
      const response = await genAi.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
            ...history.map((h: any) => ({ role: h.role, parts: [{ text: h.parts }] })),
            { role: "user", parts: [{ text: prompt }] }
        ],
        config: { systemInstruction }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });

  // Fault Diagnosis API
  app.post("/api/diagnose", async (req, res) => {
    try {
      const { symptoms } = req.body;
      const genAi = getAi();
      
      const systemInstruction = "You are a vehicle diagnostic assistant. Based on symptoms provided, list: 1. Possible causes, 2. Affected systems, 3. Recommended inspections, 4. Basic maintenance suggestions, 5. Safety precautions. Clearly state this is educational guidance and not a guaranteed diagnosis.";
      
      const response = await genAi.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: "user", parts: [{ text: `Symptoms: ${symptoms}` }] }],
        config: { systemInstruction }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });

  // Image Analyzer API
  app.post("/api/analyze-image", upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No image provided" });
      }

      const genAi = getAi();
      
      const systemInstruction = "You are an automobile engineering image analyzer. Analyze the uploaded image of an automobile component. Provide: 1. Component name, 2. Function, 3. Working principle, 4. Common faults, 5. Maintenance suggestions. If the image is unclear, state that the identification is uncertain.";
      
      const base64Image = req.file.buffer.toString('base64');
      
      const response = await genAi.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{
            role: "user", 
            parts: [
                {
                    inlineData: {
                        mimeType: req.file.mimetype,
                        data: base64Image
                    }
                },
                { text: "Analyze this automobile component." }
            ]
        }],
        config: { systemInstruction }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });

  // Viva Practice API
  app.post("/api/viva/generate", async (req, res) => {
    try {
      const { topic, difficulty } = req.body;
      const genAi = getAi();
      
      const systemInstruction = "You are an automobile engineering professor. Generate a viva (oral exam) question based on the topic and difficulty provided.";
      
      const response = await genAi.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: "user", parts: [{ text: `Topic: ${topic}, Difficulty: ${difficulty}` }] }],
        config: { systemInstruction }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/viva/evaluate", async (req, res) => {
    try {
      const { question, answer } = req.body;
      const genAi = getAi();
      
      const systemInstruction = "You are an automobile engineering professor evaluating a student's answer to a viva question. Provide: 1. Marks (out of 10), 2. Suggestions, 3. Correct explanation, 4. Improvement tips. Return JSON format with keys: marks, suggestions, explanation, tips.";
      
      const response = await genAi.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [{ role: "user", parts: [{ text: `Question: ${question}\nStudent Answer: ${answer}` }] }],
        config: { 
            systemInstruction,
            responseMimeType: "application/json"
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error: any) {
      console.error(error);
      res.status(500).json({ error: error.message });
    }
  });


  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
